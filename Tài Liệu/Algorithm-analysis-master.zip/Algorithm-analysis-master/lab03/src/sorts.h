#ifndef SORTS_H
#define SORTS_H

#include <vector>

void bubble_sort(std::vector<double> &arr);
void insertion_sort(std::vector<double> &arr);
void choice_sort(std::vector<double> &arr);

#endif //SORTS_H
