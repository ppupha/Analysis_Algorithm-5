# Расстояние Левенштейна

Предупреждаю, что отчет к этой лабе неполный(не хватает блок схем, тестовых данных, и там по мелочи).   
Требования смотреть [тут](https://github.com/Winterpuma/bmstu_AA/blob/master/lab_1/AA_lab1_task_2019.pdf).  
Более полный отчет искать в [других](https://github.com/kuso4egdobra/Analyze_Algoritms/blob/master/%D0%BE%D1%82%D1%87%D0%B5%D1%82%D0%90%D0%901.pdf) / [источниках](https://github.com/anastasialavrova/bmstu_AA/blob/master/lab_01/example.pdf).
